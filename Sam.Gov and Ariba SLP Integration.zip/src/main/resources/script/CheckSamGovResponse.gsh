import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.xml.*
import java.text.SimpleDateFormat

def Message processData(Message message) {
    // Get the JSON payload from the message body
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def jsonData = jsonSlurper.parseText(body);
    
    // Corrected variable name from 'properties' to 'mapProperties'
    def mapProperties = message.getProperties();
    def LegalName = mapProperties.get("Extract_LegalName")?.toUpperCase();
    def UEID = mapProperties.get("Extract_UEID")
    
    
    // Extract totalRecords and entityName from the JSON
    def totalRecords = jsonData?.totalRecords;
    def entityName = jsonData?.excludedEntity?.find()?.exclusionIdentification?.entityName?.toUpperCase();
    message.setProperty("entityName", entityName);
    
    // Logical conditions
    if (totalRecords == 2 && entityName == LegalName) {
	message.setProperty("comment", "ALERT!  UEI "+UEID+" is valid but found on the exclusion list.  Investigate further.");
    } else if (totalRecords == 2 && entityName != LegalName) {
        message.setProperty("comment", "ALERT!  UEI "+UEID+" is valid and found on the exclusion list, but legal name provided by supplier doesn’t match SAM.gov exclusion list.  Verify UEI and Legal Name.");
    } else if (totalRecords == 1 && entityName == LegalName) {
        message.setProperty("comment", "ALERT!  UEI "+UEID+" is valid but found on the exclusion list.  Investigate further.");
    } else if (totalRecords == 1 && entityName != LegalName) {
        message.setProperty("comment", "ALERT!  UEI "+UEID+" is valid and found on the exclusion list, but legal name provided by supplier doesn’t match SAM.gov exclusion list.  Verify UEI and Legal Name.");
    } else if (totalRecords == 0) {
        message.setProperty("comment", "UE ID "+UEID+"  is valid, active, and not found on the exclusion list");
    }

    return message;
}

def Message UEIValidation(Message message) {
    // Get the JSON payload from the message body
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def jsonData = jsonSlurper.parseText(body);
    def mapProperties = message.getProperties();
    def UEID = mapProperties.get("Extract_UEID")
   
    
    // Extract totalRecords and entityName from the JSON
    def totalRecords = jsonData?.totalRecords;
    def samRegistered = jsonData?.entityData?.find()?.entityRegistration?.samRegistered;
    def registrationStatus = jsonData?.entityData?.find()?.entityRegistration?.registrationStatus;
    def ueiStatus = jsonData?.entityData?.find()?.entityRegistration?.ueiStatus;
    def legalBusinessName = jsonData?.entityData?.find()?.entityRegistration?.legalBusinessName;
    def exclusionStatusFlag = jsonData?.entityData?.find()?.entityRegistration?.exclusionStatusFlag;
    
    // Logical conditions
    if (totalRecords == 1 && samRegistered == 'Yes' && registrationStatus == 'Active' && ueiStatus == 'Active' && exclusionStatusFlag == 'Y') {
	   // message.setProperty("comment", "UE ID is registered, and both the registration status and overall status are active.");
      message.setProperty("CheckExclusion", 'Yes');

    } else if (totalRecords == 1 && samRegistered == 'Yes' && registrationStatus == 'Active' && ueiStatus == 'Active' && exclusionStatusFlag != 'Y') {
      message.setProperty("comment", "UEI "+UEID+" is valid, active, and not found on the exclusion list.");
      message.setProperty("CheckExclusion", 'No');

    } else if (totalRecords == 1 && samRegistered == 'Yes' && registrationStatus == 'Active' && ueiStatus != 'Active' && exclusionStatusFlag != 'Y') {
      message.setProperty("comment", "Expired UEI "+UEID+".  UEI is valid and not found on the exclusion list, but Supplier must renew registration with SAM.gov to be used for Govt purchases.");
      message.setProperty("CheckExclusion", 'No');

    } else if (totalRecords == 1 && samRegistered == 'Yes' && registrationStatus == 'Active' && ueiStatus != 'Active' && exclusionStatusFlag == 'Y') {
      message.setProperty("comment", "Expired UEI "+UEID+".  UEI is valid and not found on the exclusion list, but Supplier must renew registration with SAM.gov to be used for Govt purchases.");
      message.setProperty("CheckExclusion", 'No');

    } else if (totalRecords == 0) {
        message.setProperty("comment", "Invalid UEI "+UEID+". Supplier must correct UEI or register with SAM.gov to be used for Govt purchases.");
    } else {
      message.setProperty("CheckExclusion", 'No');
    }

    return message;
}


def Message extractExclusionParameter(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String) ?: '{}')
    def reg  = json?.excludedEntity?.find()?.exclusionIdentification
    def action = json?.excludedEntity?.find()?.exclusionActions?.listOfActions?.find()

    def xml = new StreamingMarkupBuilder().bind {
        root {
            exclusion {
                totalRecords(json?.totalRecords?.toString() ?: '')
                entityName((reg?.entityName?.toUpperCase()) ?: '')
                ueiSAM(reg?.ueiSAM ?: '')
                terminationDate(action?.terminationDate ?: '')
            }
        }
    }

    message.setBody(XmlUtil.serialize(xml))
    return message
}


def Message extractEntityParameter(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String) ?: '{}')
    def reg  = json?.entityData?.find()?.entityRegistration

    def xml = new StreamingMarkupBuilder().bind {
        root {
            entity {
                totalRecords(json?.totalRecords ?: '')
                samRegistered(reg?.samRegistered ?: '')
                ueiSAM(reg?.ueiSAM ?: '')
                registrationExpirationDate(reg?.registrationExpirationDate ?: '')
                registrationStatus(reg?.registrationStatus ?: '')
                ueiStatus(reg?.ueiStatus ?: '')
                legalBusinessName(reg?.legalBusinessName ?: '')
                exclusionStatusFlag(reg?.exclusionStatusFlag ?: '')
            }
        }
    }

    message.setBody(XmlUtil.serialize(xml))
    return message
}

def Message generateComment(Message message) {
    def parsed = new XmlSlurper().parseText(message.getBody(String))
    def LegalName = message.getProperty("Extract_LegalName")?.toUpperCase()
    def UEID = message.getProperty("Extract_UEID")
    def today  = new Date()
    def sdf    = new SimpleDateFormat("yyyy-MM-dd")
    def sdfExc = new SimpleDateFormat("MM-dd-yyyy")

    def ent = parsed.'**'.find { it.name() == 'entity' }
    def entTotalRecords     = ent?.totalRecords?.text()?.trim() ?: '0'
    def entUeiSAM           = ent?.ueiSAM?.text()?.trim() ?: ''
    def samRegistered       = ent?.samRegistered?.text()?.trim() ?: ''
    def registrationStatus  = ent?.registrationStatus?.text()?.trim() ?: ''
    def regExpDateStr       = ent?.registrationExpirationDate?.text()?.trim() ?: ''
    def exclusionStatusFlag = ent?.exclusionStatusFlag?.text()?.trim() ?: ''
    def ueiStatus           = ent?.ueiStatus?.text()?.trim() ?: ''

    def exc = parsed.'**'.find { it.name() == 'exclusion' }
    def excTotalRecords  = exc?.totalRecords?.text()?.trim() ?: '0'
    def entityName       = (exc?.entityName?.text()?.trim() ?: '').toUpperCase()
    def excUeiSAM        = exc?.ueiSAM?.text()?.trim() ?: ''
    def termDateStr      = exc?.terminationDate?.text()?.trim() ?: ''

    //def uei = (entUeiSAM ?: excUeiSAM).toString()

    def entCount = entTotalRecords.isInteger() ? entTotalRecords.toInteger() : 0
    def excCount = excTotalRecords.isInteger() ? excTotalRecords.toInteger() : 0

    def regExpDate  = regExpDateStr ? sdf.parse(regExpDateStr) : null
    def isExpFuture = regExpDate ? regExpDate.after(today) : false

    def termDate     = termDateStr ? sdfExc.parse(termDateStr) : null
    def isTermFuture = termDate ? termDate.after(today) : false

    def comment = ''

    if (entCount == 0 && excCount == 0) {
        comment = "Invalid UEI ${UEID}. Supplier must correct UEI or register with SAM.gov to be used for Govt purchases."
    } else if (entCount == 0 && excCount > 0 && isTermFuture) {
        if (LegalName && LegalName == entityName) {
            comment = "ALERT! UEI ${UEID} is valid but found on the exclusion list. Investigate further."
        } else {
            comment = "ALERT! UEI ${UEID} is valid and found on the exclusion list, but legal name provided by supplier doesn't match SAM.gov exclusion list. Verify UEI and Legal Name."
        }
    } else if (entCount > 0 && samRegistered == 'Yes' && registrationStatus == 'Active') {
        if (isExpFuture && exclusionStatusFlag == 'Y' && excCount > 0) {
            if (LegalName && LegalName == entityName) {
                comment = "ALERT! UEI ${UEID} is valid but found on the exclusion list. Investigate further."
            } else {
                comment = "ALERT! UEI ${UEID} is valid and found on the exclusion list, but legal name provided by supplier doesn't match SAM.gov exclusion list. Verify UEI and Legal Name."
            }
        } else if (isExpFuture && exclusionStatusFlag == 'N' && excCount == 0) {
            comment = "UEI ${UEID} is valid, active, and not found on the exclusion list. Renew Registration on ${regExpDateStr}."
        } else if (!isExpFuture && exclusionStatusFlag == 'Y' && excCount > 0) {
            if (LegalName && LegalName == entityName) {
                comment = "ALERT! UEI ${UEID} is valid but found on the exclusion list. Investigate further."
            } else {
                comment = "ALERT! UEI ${UEID} is valid and found on the exclusion list, but legal name provided by supplier doesn't match SAM.gov exclusion list. Verify UEI and Legal Name."
            }
        }
      } else if (entCount > 0 && samRegistered == 'Yes' && registrationStatus == 'Inactive' && ueiStatus == 'Active' && !isExpFuture && exclusionStatusFlag == 'N' && excCount == 0) {
          comment = "Expired UEI ${UEID} on: ${regExpDateStr}.UEI is valid and not found on the exclusion list, but Supplier must renew registration with SAM.gov to be used for Govt purchases."
      }

    message.setHeader("comment", comment.toString())
    return message
}