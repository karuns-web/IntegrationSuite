import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {
    def apikey_alias = message.getProperty("Ariba_APIKEY")
    def SLPKey_alias = message.getProperty("Sam.Gov_APIKEY")
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    try{
        def secureParameter = secureStorageService.getUserCredential(apikey_alias)
        def apikey = secureParameter.getPassword().toString()
        message.setHeader("APIKEY", apikey)
        def SamsecureParam = secureStorageService.getUserCredential(SLPKey_alias)
        def SamGovapikey = SamsecureParam.getPassword().toString()
        message.setHeader("SamGovapikey", SamGovapikey)
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not available")
    }
    return message;
}
