import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve the JSON input from the message body
    def inputJson = message.getBody(String)

    // Parse the JSON input
    def jsonSlurper = new JsonSlurper()
    def parsedJson = jsonSlurper.parseText(inputJson)

    // Add the root element
    def wrappedJson = ['root': parsedJson]

    // Perform any transformations on the JSON (optional)
    wrappedJson.root['formattedDate'] = new Date(parsedJson.beginDate).toString() // Example transformation

    // Convert JSON to string in pretty format
    def formattedJson = JsonOutput.prettyPrint(JsonOutput.toJson(wrappedJson))

    // Encode the formatted JSON as UTF-8
    //def utf8EncodedJson = formattedJson.getBytes("UTF-8")

    // Set the encoded JSON back into the message body
    message.setBody(new String(formattedJson))

    return message
}