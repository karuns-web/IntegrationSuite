import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper


def Message processData(Message message) {
    // Retrieve the JSON input from the message body
    def inputJson = message.getBody(String)

// Parse the JSON payload
def parsedJson = new JsonSlurper().parseText(inputJson)
def map = message.getProperties()
// Variable to store the desired answer value
def legalNameValue = map.get("LegalName")
def ueidValue = map.get("UEID")

parsedJson.root.document.content.answers.each { answer ->
    if (answer.externalSystemCorrelationId == legalNameValue && answer.questionLabel.contains("Legal Name")) {
        message.setProperty("Extract_LegalName", answer.answer)
    }
    if (answer.externalSystemCorrelationId == ueidValue && answer.questionLabel.contains("UEI (Unique Entity Identifier)")) {
        message.setProperty("Extract_UEID", answer.answer)
    }
}


// Return the modified message
return message
}