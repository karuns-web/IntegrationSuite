import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

// Internal function to be called from different log payload functions 
def Message logPayloadInternal(Message message, String payloadName) {
    // Get properties and headers
    def pMap = message.getProperties();
    def hMap = message.getHeaders();

    // Check if logging is enabled
    if ((pMap.get("P_EnableLogging") != null && pMap.get("P_EnableLogging").equalsIgnoreCase("TRUE")) ||
        (pMap.get("p_enable_logging") != null && pMap.get("p_enable_logging").equalsIgnoreCase("TRUE")) ||
        (pMap.get("P_ENABLE_LOGGING") != null && pMap.get("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE"))) {
        
        def body = message.getBody(java.lang.String);
        def messageLog = messageLogFactory.getMessageLog(message);

        if (messageLog != null) {
            // Add payload attachment
            messageLog.addAttachmentAsString(payloadName, body, "text/xml");
        }
    }
    return message;
}

// Log Payload
def Message logPayload(Message message) {
    def hMap = message.getHeaders(); // Ensure hMap is properly defined
    String attachName = hMap.get("UEID"); // Retrieve the "UEID" header value
    return logPayloadInternal(message, attachName);
}

// Log payload after conversion - with split counter
def Message logAfterSplitAndConversion(Message message) {
    def pMap = message.getProperties();
    
    // For standard Splitter
    def splitIndex = pMap.get("CamelSplitIndex");
    
    // While using custom splitter logic (for looping process call)
    if (splitIndex == null) {
        splitIndex = pMap.get("CamelLoopIndex");
    }
    if (splitIndex == null) {
        splitIndex = 0;
    }

    // Call the internal log function
    return logPayloadInternal(message, "Payload after Conversion " + (splitIndex + 1));
}